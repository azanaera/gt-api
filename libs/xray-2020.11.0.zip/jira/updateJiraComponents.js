const _ = require("lodash"),
    fs = require("fs"),
    readline = require("readline"),
    jiraApi = require("./jiraApi.js"),
    merge = require("./../junitMerge/index.js"),
    logUtil = require("./../util/logUtilities.js"),
    xrayTestPattern = /^@TEST_-\d+$/,
    cucumberTestFiles = ".feature",
    junitTestFiles = ".java";

async function findAndAssociateComponentsToTests(dirOfTestsToUpdate, excludedFolders, testsFileType) {
  try {
    //Find all the test files based on fileType of tests
    const files = await merge.listFilesByType(dirOfTestsToUpdate, true, testsFileType, excludedFolders);
    let jirasToUpdate = [],
        fileCount = files.length;
    if (files) {
      for (const file of files) {
        let foundComponentName = false,
            xrayTestJiraID = "",
            testSummary = "",
            foundXrayTestId = false,
            noComponentInFeature = false,
            rl = readline.createInterface({
              input: fs.createReadStream(file)
            }),
            componentAddData = {
              "update": {
                "components": [
                  {
                    "set":  [{"name":"$componentName"}]
                  }
                ]
              }
            },
            lookForJunitTestName = false;

        // Go through the current file, line-by-line...
        rl.on("line", async (line) => {
          let lineSplits = [],
              componentName = "";
          if (foundXrayTestId && !noComponentInFeature && (xrayTestJiraID || testSummary)) {
            jirasToUpdate.push({
              jiraId: xrayTestJiraID,
              componentData: componentAddData,
              jiraSummary: testSummary
            });
            xrayTestJiraID = "";
            testSummary = "";
          }
          line = _.trim(line);

          if (line) {
            if (testsFileType === cucumberTestFiles) {
              //cucumber tests
              switch (true) {
                case (_.startsWith(line, "@TestComponent=") && !foundComponentName && !noComponentInFeature):
                  //feature file component must be defined at the start of the file in the format @TestComponent="componentName"
                  //parse the component name string, replace any _ with spaces and remove the quotations
                  componentName = _.replace(line, "@TestComponent=", "").split("_").join(" ");
                  componentAddData = _.replace(JSON.stringify(componentAddData), "$componentName", componentName);
                  foundComponentName = true;
                  break;
                case (_.startsWith(line, "Feature:")) :
                  //if the feature file does not have a component defined we do not need to update any tests in xray
                  noComponentInFeature = JSON.stringify(componentAddData).includes("$componentName");
                  break;
                case (_.startsWith(line, "Scenario:")) :
                  //use the test summary to find the jira key if no jira key is found
                  if (!foundXrayTestId) {
                    foundXrayTestId = true;
                    testSummary = _.trim(_.replace(line, "Scenario:", ""));
                  } else {
                    foundXrayTestId = false;
                  }
                  break;
                case (_.startsWith(line, "Scenario Outline:")) :
                  //use the test summary to find the jira key if no jira key is found
                  if (!foundXrayTestId) {
                    foundXrayTestId = true;
                    testSummary = _.trim(_.replace(line, "Scenario Outline:", ""));
                  } else {
                    foundXrayTestId = false;
                  }
                  break;
                case (_.startsWith(line, "@")) :
                  //finds the jira key if defined at start of scenario
                  lineSplits = _.split(line, " ");
                  foundXrayTestId = false;
                  _.each(lineSplits, function (lineSplit) {
                    const xrayId = lineSplit.substring(1);

                    if (xrayTestPattern.test(lineSplit)) {
                      foundXrayTestId = true;
                      xrayTestJiraID = _.replace(xrayId,'TEST_','');
                    }
                  });
                  break;
                default:
                  foundXrayTestId = false;
              }
            } else if (testsFileType === junitTestFiles) {
              //Junit tests
              switch (true) {
                case (_.startsWith(line, "@TestComponent") && !foundComponentName):
                  //finds the testComponent
                  componentName = line.substring(line.lastIndexOf('"'), line.indexOf('"') + 1);
                  componentAddData = _.replace(JSON.stringify(componentAddData), "$componentName", componentName);
                  foundComponentName = true;
                  break;
                case (_.trim(line) === "@Test") :
                  //finds each test to update
                  lookForJunitTestName = true;
                  noComponentInFeature = JSON.stringify(componentAddData).includes("$componentName");
                  break;
                case (_.startsWith(line, "public void") && lookForJunitTestName) :
                  //use the test name/summary to get the jiraKey
                  testSummary = line.substring(
                      line.indexOf("public void ") + 12,
                      line.lastIndexOf("()")
                  );
                  lookForJunitTestName = false;
                  foundXrayTestId = true;
                  break;
                default:
                  foundXrayTestId = false;
              }
            }
          }
        });

        rl.on("close", function () {
          // And we have processed the last file...
          if (!--fileCount) {
            // Update Jira Xray Test Components
            let p = Promise.resolve();
            _.each(jirasToUpdate, (jiraToUpdate) => {
              p = p.then(async function () {
                if (!jiraToUpdate.jiraId && jiraToUpdate.jiraSummary) {
                  let bodyData = {
                    "expand": [
                      "key"
                    ],

                    "jql": "issuetype = 'Xray Test' AND project = " + global.projectId + " AND summary ~ '$testSummary'",
                    "maxResults": 15,
                    "fieldsByKeys": false,
                    "fields": [
                      "summary"
                    ],
                    "startAt": 0
                  };
                  bodyData = _.replace(JSON.stringify(bodyData), "$testSummary", _.trim(jiraToUpdate.jiraSummary));
                  jiraToUpdate.jiraId = await jiraApi.getJiraIdBySummary(bodyData, jiraToUpdate.jiraSummary);
                }
                return await jiraApi.updateJiraComponent(jiraToUpdate.componentData, jiraToUpdate.jiraId);
              }.bind(this));
            });
            return p;
          }
        });

        rl.on("error", function (err) {
          console.error(err);
          throw err;
        });

      }
    }
  }catch (e) {
    console.error(e);
    throw e;
  }
}

module.exports = {
  findAndAssociateComponentsToTests
};

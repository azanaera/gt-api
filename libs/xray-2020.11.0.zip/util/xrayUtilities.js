global.testInfoFileIndex = 0;
const _ = require("lodash"),
    axios = require("axios").default,
    fs = require("fs"),
    path = require("path"),
    process = require("process"),
    logUtil = require("./logUtilities.js"),
    readline = require("readline"),
    xrayAuth = {
        "client_id": process.env.xray_client_id,
        "client_secret": process.env.xray_client_secret
    };

/**
 * Walks through the given directory, and all subdirectories,
 * executing the "done" callback with a list of all files of the given type,
 * or all files if no type is specified.
 * @param dir       directory to walk
 * @param fileType  the type of file to filter on
 * @param done      callback that will be invoked when the walk is complete.
 */
function walk(dir, fileType, done) {
    let results = [];

    fs.readdir(dir, function (err, list) {
        if (err) {
            return done(err);
        }

        let pending = list.length;
        if (!pending) {
            return done(null, results);
        }

        _.each(list, function (file) {
            file = path.resolve(dir, file);
            fs.stat(file, function (err, stat) {
                if (stat && stat.isDirectory()) {
                    walk(file, fileType, function (err, res) {
                        results = results.concat(res);
                        if (!--pending) {
                            done(null, results);
                        }
                    });
                } else {
                    if (!fileType || file.endsWith(fileType)) {
                        results.push(file);
                    }

                    if (!--pending) {
                        done(null, results);
                    }
                }
            });
        });
    });
};

async function createTestCaseInfoFile(featureFile){

    return new Promise((resolve, reject) => {

        let rl = readline.createInterface({
                input: fs.createReadStream(featureFile)
            }),
            defaultComponent = "None",
            foundComponent = false,
            testCaseInfo = {
                "fields":{
                    "components": [{
                        "name": defaultComponent
                    }]
                },
                "update": {}
            };
        //Go through the current file, line-by-line...
        rl.on("line", async (line) => {

            if(line){
                switch (true) {
                    case (_.startsWith(line, "@TestComponent=")):
                        //feature file component must be defined at the start of the file in the format @TestComponent="componentName"
                        //parse the component name string, replace any _ with spaces and remove the quotations
                        componentName = _.replace(line, "@TestComponent=", "").split("_").join(" ");
                        testCaseInfo = _.replace(JSON.stringify(testCaseInfo), defaultComponent, componentName);
                        foundComponent = true;
                        rl.close();
                        rl.removeAllListeners();
                        tcInfoFile = "../main/testInfo_"+  ++global.testInfoFileIndex +".json";
                        fs.writeFileSync(tcInfoFile,testCaseInfo);
                        resolve(tcInfoFile);
                        break;
                    case (_.startsWith(line, "Feature:")):
                        rl.close();
                        rl.removeAllListeners();
                        reject(console.error("Unable to find component annotation within feature file: " + JSON.stringify(featureFile)));
                }
            }
        });
    });


}


/**
 * creates the authorization token in order to access Xray APIs
 */
async function createAuthenticationToken() {
    axios.defaults.headers.post["Content-Type"] = "application/json";
    const options = {
        method: "POST",
        url: "https://xray.cloud.xpand-it.com/api/v1/authenticate",
        json: true,
        data: xrayAuth
    };
    try {
        const response = await axios(options);
        return response.data;
    } catch (error){
        logUtil.logHttpError(error);
    };
}


module.exports = {
    createAuthenticationToken,
    walk,
    createTestCaseInfoFile
};




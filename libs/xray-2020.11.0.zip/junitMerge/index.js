const fs = require("fs");
const fspath = require("path");
const read = require("fs-readdir-recursive");
const xmldoc = require("xmldoc");
const mkdirp = require("mkdirp");
const _ = require("lodash");
const xrayUtilities = require("./../util/xrayUtilities");

module.exports.testsuiteCount = 0;
module.exports.testsuites = [];

/**
 * Read XML from file
 * @param {string} fileName
 */
function parseXmlFromFile(fileName) {
  try {
    const xmlFile = fs.readFileSync(fileName, "utf8");
    const xmlDoc = new xmldoc.XmlDocument(xmlFile);

    // Single testsuite, not wrapped in a testsuites
    if (xmlDoc.name === "testsuite") {
      module.exports.testsuites = xmlDoc;
      module.exports.testsuiteCount = 1;
    } else {
      // Multiple testsuites, wrapped in a parent
      module.exports.testsuites = xmlDoc.childrenNamed("testsuite");
      module.exports.testsuiteCount = module.exports.testsuites.length;
    }

    return xmlDoc;
  } catch (e) {
    if (e.code === "ENOENT") {
      // Bad directory
      throw new Error("File not found");
    }
    // Unknown error
    throw e;
  }
}

/**
 * List all files in directory by type
 * @param {*} path
 * @param {*} recursive
 * @param {*} fileType
 * @param {*} excludedDirs
 */
function listFilesByType(path, recursive, fileType, excludedDirs) {
  try {
    const allFiles = recursive ? read(path) : fs.readdirSync(path);

    const files = allFiles
        .map(function(file) {
          if (excludedDirs) {
            if (!excludedDirs.includes(file.substring(0, file.indexOf("\\")))) {
              return fspath.join(path, file);
            }
          }else{
            return fspath.join(path, file);
          }
        })
        // Fiter out non-files
        .filter(function(file) {
          if (file) {
            return fs.statSync(file).isFile();
          }
        })
        // Only return files ending in specified fileType
        .filter(function(file) {
          if (fileType) {
            const length = parseInt(fileType.length)
            return file.slice(-length) === fileType;
          }
        });
    // No files returned
    if (!files.length > 0) {
      return new Error("No files found");
    } else {
      return files;
    }
  } catch (e) {
    throw e;
  }
}

/**
 * Extract JUNIT test suites from XML
 * @param {*} filename
 */
function getTestsuites(filename) {
  const xmlFile = parseXmlFromFile(filename);
  try {
    let testsuites = "";
    // Single testsuite, not wrapped in a testsuites
    if (xmlFile.name === "testsuite") {
      return xmlFile.toString();
    } else {
      // Multiple testsuites, wrapped in a parent
      const testsuitesXml = xmlFile.childrenNamed("testsuite");
      testsuitesXml.forEach(function(testsuite) {
        testsuites += testsuite.toString() + "\n";
      });
      return testsuites;
    }
  } catch (e) {
    if (e.message === "xmlFile.childrenNamed is not a function") {
      throw new Error("No tests found");
    } else {
      throw e;
    }
  }
}

function mergeFiles(files) {
  let mergedTestSuites = "";
  let mergedFile = "";
  files.forEach(function(file) {
    try {
      const res = getTestsuites(file);
      mergedTestSuites += res + "\n";
      if (mergedTestSuites === "") {
        throw new Error("No tests found");
      }
    } catch (err) {
      if (err.message != "No tests found") {
        console.error(err);
        throw err;
      }
    }
  });
  mergedFile =
      '<?xml version="1.0"?>\n' +
      "<testsuites>\n" +
      mergedTestSuites +
      "</testsuites>";
  return mergedFile;
}

function writeMergedFile(file, data, createOutputDir) {
  try {
    fs.writeFileSync(file, data);
  } catch (error) {
    if (error.code == "ENOENT") {
      if (createOutputDir) {
        mkdirp.sync(file.substr(0, file.lastIndexOf("/")));
        fs.writeFileSync(file, data);
      } else {
        throw new Error("Missing output directory");
      }
    }
  }
}

module.exports = {
  listFilesByType,
  mergeFiles,
  getTestsuites,
  writeMergedFile,
};
